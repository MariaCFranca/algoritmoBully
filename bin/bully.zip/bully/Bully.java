package bully;
//import Processo;
//import Threads;
import java.util.ArrayList;
import java.util.List;
import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.ui.view.Viewer;

public class Bully {

	public List<Processo> listaProcessos = new ArrayList<>();
	public Processo coordenador;
	public static Graph graph = new SingleGraph("Bully Algorithm");
	
	public static void main(String[] args) throws InterruptedException {
		Thread a = new Thread(Threads.vinteCincoSegundos);
		Thread b = new Thread(Threads.trintaSegundos);
		Thread c = new Thread(Threads.oitentaSegundos);
		Thread d = new Thread(Threads.cemSegundos);
		
		a.setName("vinteCincoSegundos");
		b.setName("trintaSegundos");
		c.setName("oitentaSegundos");
		d.setName("cemSegundos");
		
		a.start();
		b.start();
		c.start();
		d.start();		

		Viewer viewer = graph.display();
	}
}
