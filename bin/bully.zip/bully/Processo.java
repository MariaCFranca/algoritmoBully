package bully;

import org.w3c.dom.Node;

public class Processo {
	
	private boolean isCoordenador;
	private int iID;
	private boolean ativo;
	private Processo coordenador;
	 private Node node;
	
	public Processo getCoordenador() {
		return coordenador;
	}
	
	public void setCoordenador(Processo coordenador) {
		this.coordenador = coordenador;
	}
	
	public Processo(int id) {
		this.isCoordenador = false;
		this.iID = id;
		this.ativo = true;
		this.node = Bully.graph.addNode(Integer.toString(id));
        this.node.addAttribute("ui.label", Integer.toString(id));
	}
	
	public boolean isbCoordenador() {
		return isCoordenador;
	}
	
	public void setbCoordenador(boolean bCoordenador) {
		this.isCoordenador = bCoordenador;
	}
	
	public int getiID() {
		return this.iID;
	}
	
	public void setiID(int iID) {
		this.iID = iID;
	}
	
	public boolean isAtivo() {
		return ativo;
	}
	
	public void setAtivo(boolean ativo) {
		this.ativo = ativo;
	}
}
